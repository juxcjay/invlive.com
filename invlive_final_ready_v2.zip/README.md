InvLive final package v2
Files:
- server.js
- index.html
- admin.html
- .env.example (contains your BTC address and admin email)
- package.json, db.json

Quick start:
npm install
cp .env.example .env
node server.js
